data.push({
    groupId: 1,
    groupName: '2021计科1班公费',
    module: '高等数学',
    room: '理工一133',
    professor: '李持磊',
    timeslotId: 2
})
data.push({
    groupId: 1,
    groupName: '2021计科1班公费',
    module: '体育1',
    room: '',
    professor: '',
    timeslotId: 3
})
data.push({
    groupId: 1,
    groupName: '2021计科1班公费',
    module: '大学英语1',
    room: '',
    professor: '',
    timeslotId: 6
})
data.push({
    groupId: 1,
    groupName: '2021计科1班公费',
    module: '线性代数',
    room: '理工一523',
    professor: '王金江',
    timeslotId: 10
})
data.push({
    groupId: 1,
    groupName: '2021计科1班公费',
    module: '线性代数',
    room: '理工一521',
    professor: '王金江',
    timeslotId: 11
})
data.push({
    groupId: 1,
    groupName: '2021计科1班公费',
    module: '高等数学',
    room: '理工一133',
    professor: '李持磊',
    timeslotId: 12
})
data.push({
    groupId: 1,
    groupName: '2021计科1班公费',
    module: '高等数学',
    room: '理工一133',
    professor: '李持磊',
    timeslotId: 16
})
data.push({
    groupId: 1,
    groupName: '2021计科1班公费',
    module: '大学英语1(双周)',
    room: '',
    professor: '',
    timeslotId: 15
})
data.push({
    groupId: 1,
    groupName: '2021计科1班公费',
    module: '大学生心理健康',
    room: '理工一411',
    professor: '张洪岩',
    timeslotId: 18
})
data.push({
    groupId: 1,
    groupName: '2021计科2班行知班',
    module: '高等数学',
    room: '理工一121',
    professor: '刘宏丽',
    timeslotId: 1
})
data.push({
    groupId: 2,
    groupName: '2021计科2班行知班',
    module: '体育1',
    room: '',
    professor: '',
    timeslotId: 3
})
data.push({
    groupId: 2,
    groupName: '2021计科2班行知班',
    module: '大学英语1',
    room: '',
    professor: '',
    timeslotId: 6
})
data.push({
    groupId: 2,
    groupName: '2021计科2班行知班',
    module: '线性代数',
    room: '理工一523',
    professor: '王金江',
    timeslotId: 10
})
data.push({
    groupId: 2,
    groupName: '2021计科2班行知班',
    module: '线性代数',
    room: '理工一521',
    professor: '王金江',
    timeslotId: 11
})
data.push({
    groupId: 2,
    groupName: '2021计科2班行知班',
    module: '高等数学',
    room: '理工一121',
    professor: '刘宏丽',
    timeslotId: 12
})
data.push({
    groupId: 2,
    groupName: '2021计科2班行知班',
    module: '大学生心理健康',
    room: '理工一411',
    professor: '朱佳隽',
    timeslotId: 14
})
data.push({
    groupId: 2,
    groupName: '2021计科2班行知班',
    module: '大学英语1(单)高数数学1(双)',
    room: '',
    professor: '刘宏丽',
    timeslotId: 15
})
data.push({
    groupId: 3,
    groupName: '2021计科34班',
    module: '线性代数',
    room: '理工一521',
    professor: '丁磊',
    timeslotId: 1
})
data.push({
    groupId: 3,
    groupName: '2021计科34班',
    module: '线性代数',
    room: '理工一521',
    professor: '丁磊',
    timeslotId: 7
})
data.push({
    groupId: 3,
    groupName: '2021计科34班',
    module: '体育1',
    room: '',
    professor: '',
    timeslotId: 3
})
data.push({
    groupId: 3,
    groupName: '2021计科34班',
    module: '大学英语1',
    room: '',
    professor: '',
    timeslotId: 6
})
data.push({
    groupId: 3,
    groupName: '2021计科34班',
    module: '高等数学1',
    room: '理工一521',
    professor: '迟薇',
    timeslotId: 9
})
data.push({
    groupId: 3,
    groupName: '2021计科34班',
    module: '高等数学1',
    room: '理工一521',
    professor: '迟薇',
    timeslotId: 12
})
data.push({
    groupId: 3,
    groupName: '2021计科34班',
    module: '大学英语1',
    room: '',
    professor: '',
    timeslotId: 15
})
data.push({
    groupId: 3,
    groupName: '2021计科34班',
    module: '高等数学1',
    room: '理工一521',
    professor: '迟薇',
    timeslotId: 16
})
data.push({
    groupId: 3,
    groupName: '2021计科34班',
    module: '大学生心理健康',
    room: '理工一411',
    professor: '张洪岩',
    timeslotId: 18
})
data.push({
    groupId: 4,
    groupName: '2021软件工程12班',
    module: '体育1',
    room: '',
    professor: '',
    timeslotId: 3
})
data.push({
    groupId: 4,
    groupName: '2021软件工程12班',
    module: '高等数学1',
    room: '理工一429',
    professor: '张译元',
    timeslotId: 5
})
data.push({
    groupId: 4,
    groupName: '2021软件工程12班',
    module: '大学英语1',
    room: '',
    professor: '',
    timeslotId: 6
})
data.push({
    groupId: 4,
    groupName: '2021软件工程12班',
    module: '大学生心理健康',
    room: '理工一411',
    professor: '马林',
    timeslotId: 7
})
data.push({
    groupId: 4,
    groupName: '2021软件工程12班',
    module: '线性代数',
    room: '理工一429',
    professor: '王金江',
    timeslotId: 13
})
data.push({
    groupId: 4,
    groupName: '2021软件工程12班',
    module: '高等数学1',
    room: '理工一429',
    professor: '张译元',
    timeslotId: 12
})
data.push({
    groupId: 4,
    groupName: '2021软件工程12班',
    module: '高等数学1',
    room: '理工一429',
    professor: '张译元',
    timeslotId: 16
})
data.push({
    groupId: 4,
    groupName: '2021软件工程12班',
    module: '大学英语1',
    room: '',
    professor: '',
    timeslotId: 15
})
data.push({
    groupId: 5,
    groupName: '2021软件工程34班',
    module: '高等数学',
    room: '理工一431',
    professor: '刘宏丽',
    timeslotId: 2
})
data.push({
    groupId: 5,
    groupName: '2021软件工程34班',
    module: '体育1',
    room: '',
    professor: '',
    timeslotId: 3
})
data.push({
    groupId: 5,
    groupName: '2021软件工程34班',
    module: '大学英语1',
    room: '',
    professor: '',
    timeslotId: 6
})
data.push({
    groupId: 5,
    groupName: '2021软件工程34班',
    module: '大学生心理健康',
    room: '理工一411',
    professor: '马林',
    timeslotId: 7
})
data.push({
    groupId: 5,
    groupName: '2021软件工程34班',
    module: '线性代数',
    room: '理工一431',
    professor: '王金江',
    timeslotId: 8
})
data.push({
    groupId: 5,
    groupName: '2021软件工程34班',
    module: '高等数学',
    room: '理工一431',
    professor: '刘宏丽',
    timeslotId: 11
})
data.push({
    groupId: 5,
    groupName: '2021软件工程34班',
    module: '线性代数',
    room: '理工一431',
    professor: '王金江',
    timeslotId: 14
})
data.push({
    groupId: 5,
    groupName: '2021软件工程34班',
    module: '大学英语1',
    room: '',
    professor: '',
    timeslotId: 15
})
data.push({
    groupId: 5,
    groupName: '2021软件工程34班',
    module: '高等数学',
    room: '理工一431',
    professor: '刘宏丽',
    timeslotId: 16
})
data.push({
    groupId: 6,
    groupName: '2021数媒专业',
    module: '高等数学',
    room: '理工一411',
    professor: '李持磊',
    timeslotId: 1
})
data.push({
    groupId: 6,
    groupName: '2021数媒专业',
    module: '线性代数',
    room: '理工一411',
    professor: '丁磊',
    timeslotId: 2
})
data.push({
    groupId: 6,
    groupName: '2021数媒专业',
    module: "体育1",
    room: "",
    professor: "",
    timeslotId: 3
})
data.push({
    groupId: 6,
    groupName: '2021数媒专业',
    module: "大学英语1",
    room: "",
    professor: "",
    timeslotId: 6
})
data.push({
    groupId: 6,
    groupName: '2021数媒专业',
    module: '高等数学',
    room: '理工一411',
    professor: '李持磊',
    timeslotId: 9
})
data.push({
    groupId: 6,
    groupName: '2021数媒专业',
    module: '高等数学',
    room: '理工一411',
    professor: '李持磊',
    timeslotId: 11
})
data.push({
    groupId: 6,
    groupName: '2021数媒专业',
    module: '大学生心理健康',
    room: '理工一411',
    professor: '朱佳隽',
    timeslotId: 14
})
data.push({
    groupId: 6,
    groupName: '2021数媒专业',
    module: '大学英语1',
    room: '',
    professor: '',
    timeslotId: 15
})
data.push({
    groupId: 6,
    groupName: '2021数媒专业',
    module: '线性代数',
    room: '理工一411',
    professor: '丁磊',
    timeslotId: 18
})
data.push({
    groupId: 7,
    groupName: '2021物联网工程',
    module: '高等数学',
    room: '理工一117',
    professor: '王洪杰',
    timeslotId: 1
})
data.push({
    groupId: 7,
    groupName: '2021物联网工程',
    module: "体育1",
    room: "",
    professor: "",
    timeslotId: 3
})
data.push({
    groupId: 7,
    groupName: '2021物联网工程',
    module: '线性代数',
    room: '理工一117',
    professor: '李小彦',
    timeslotId: 4
})
data.push({
    groupId: 7,
    groupName: '2021物联网工程',
    module: '线性代数',
    room: '理工一117',
    professor: '李小彦',
    timeslotId: 8
})
data.push({
    groupId: 7,
    groupName: '2021物联网工程',
    module: "大学英语1",
    room: "",
    professor: "",
    timeslotId: 6
})
data.push({
    groupId: 7,
    groupName: '2021物联网工程',
    module: '高等数学',
    room: '理工一117',
    professor: '王洪杰',
    timeslotId: 9
})
data.push({
    groupId: 7,
    groupName: '2021物联网工程',
    module: '大学英语1(双)高等数学1(单)',
    room: '理工一117',
    professor: '王洪杰',
    timeslotId: 15
})
data.push({
    groupId: 7,
    groupName: '2021物联网工程',
    module: '大学生心理健康',
    room: '理工一411',
    professor: '张洪岩',
    timeslotId: 16
})
data.push({
    groupId: 8,
    groupName: '2021大数据1班',
    module: '线性代数',
    room: '理工一119',
    professor: '李小彦',
    timeslotId: 1
})
data.push({
    groupId: 8,
    groupName: '2021大数据1班',
    module: '高等数学',
    room: '理工一119',
    professor: '贺裕',
    timeslotId: 2
})
data.push({
    groupId: 8,
    groupName: '2021大数据1班',
    module: "体育1",
    room: "",
    professor: "",
    timeslotId: 3
})
data.push({
    groupId: 8,
    groupName: '2021大数据1班',
    module: "大学英语1",
    room: "",
    professor: "",
    timeslotId: 6
})
data.push({
    groupId: 8,
    groupName: '2021大数据1班',
    module: '线性代数',
    room: '理工一119',
    professor: '李小彦',
    timeslotId: 7
})
data.push({
    groupId: 8,
    groupName: '2021大数据1班',
    module: '高等数学',
    room: '理工一119',
    professor: '贺裕',
    timeslotId: 10
})
data.push({
    groupId: 8,
    groupName: '2021大数据1班',
    module: '高等数学',
    room: '理工一119',
    professor: '贺裕',
    timeslotId: 12
})
data.push({
    groupId: 8,
    groupName: '2021大数据1班',
    module: '大学英语1(双)',
    room: '',
    professor: '',
    timeslotId: 15
})
data.push({
    groupId: 8,
    groupName: '2021大数据1班',
    module: '大学生心理健康',
    room: '理工一411',
    professor: '张洪岩',
    timeslotId: 16
})
data.push({
    groupId: 9,
    groupName: '2020计科1班公费',
    module: '大学英语3',
    room: '',
    professor: '',
    timeslotId: 1
})
data.push({
    groupId: 9,
    groupName: '2020计科1班公费',
    module: '概率论与数理统计',
    room: '理工一123',
    professor: '张馥菊',
    timeslotId: 2
})
data.push({
    groupId: 9,
    groupName: '2020计科1班公费',
    module: '中国近现代史纲要',
    room: '崇C306',
    professor: '苑爽',
    timeslotId: 5
})
data.push({
    groupId: 9,
    groupName: '2020计科1班公费',
    module: '体育3',
    room: '',
    professor: '',
    timeslotId: 10
})
data.push({
    groupId: 9,
    groupName: '2020计科1班公费',
    module: '大学英语3(双)web程序设计与框架应用（实）',
    room: '',
    professor: '房益国',
    timeslotId: 12
})
data.push({
    groupId: 9,
    groupName: '2020计科1班公费',
    module: '中国近现代史纲要',
    room: '崇C306',
    professor: '苑爽',
    timeslotId: 13
})
data.push({
    groupId: 9,
    groupName: '2020计科1班公费',
    module: '概率论与数理统计',
    room: '理工一123',
    professor: '张馥菊',
    timeslotId: 16
})
data.push({
    groupId: 9,
    groupName: '2020计科1班公费',
    module: '教育学原理',
    room: '崇C103',
    professor: '王丽丽',
    timeslotId: 17
})
data.push({
    groupId: 10,
    groupName: '2020计科2班',
    module: '大学英语3',
    room: '',
    professor: '',
    timeslotId: 1
})
data.push({
    groupId: 10,
    groupName: '2020计科2班',
    module: '概率论与数理统计',
    room: '体育309',
    professor: '张伟',
    timeslotId: 2
})
data.push({
    groupId: 10,
    groupName: '2020计科2班',
    module: '概率论与数理统计',
    room: '理工一133',
    professor: '张伟',
    timeslotId: 6
})
data.push({
    groupId: 10,
    groupName: '2020计科2班',
    module: '中国近现代史纲要',
    room: '崇D502',
    professor: '苑爽',
    timeslotId: 4
})
data.push({
    groupId: 10,
    groupName: '2020计科2班',
    module: '体育3',
    room: '',
    professor: '',
    timeslotId: 10
})
data.push({
    groupId: 10,
    groupName: '2020计科2班',
    module: '大学英语3（双）',
    room: '',
    professor: '',
    timeslotId: 12
})
data.push({
    groupId: 10,
    groupName: '2020计科2班',
    module: '中国近现代史纲要',
    room: '崇D502',
    professor: '苑爽',
    timeslotId: 14
})
data.push({
    groupId: 10,
    groupName: '2020计科2班',
    module: "教育学原理",
    room: '崇C103',
    professor: '王丽丽',
    timeslotId: 17
})
data.push({
    groupId: 11,
    groupName: '2020计科34班',
    module: '大学英语3',
    room: '',
    professor: '',
    timeslotId: 1
})
data.push({
    groupId: 11,
    groupName: '2020计科34班',
    module: '中国近现代史纲要',
    room: '崇D502',
    professor: '苑爽',
    timeslotId: 4
})
data.push({
    groupId: 11,
    groupName: '2020计科34班',
    module: '概率论与数理统计',
    room: '体育211',
    professor: '张馥菊',
    timeslotId: 6
})
data.push({
    groupId: 11,
    groupName: '2020计科34班',
    module: '体育3',
    room: '',
    professor: '',
    timeslotId: 10
})
data.push({
    groupId: 11,
    groupName: '2020计科34班',
    module: '大学英语3（双）概率论与数理统计（单）',
    room: '体育211',
    professor: '张馥菊',
    timeslotId: 12
})
data.push({
    groupId: 11,
    groupName: '2020计科34班',
    module: '中国近现代史纲要',
    room: '崇D502',
    professor: '苑爽',
    timeslotId: 14
})
data.push({
    groupId: 12,
    groupName: '2020计科56班',
    module: '大学英语3',
    room: '',
    professor: '',
    timeslotId: 1
})
data.push({
    groupId: 12,
    groupName: '2020计科56班',
    module: '概率论与数理统计',
    room: '体育309',
    professor: '张伟',
    timeslotId: 2
})
data.push({
    groupId: 12,
    groupName: '2020计科56班',
    module: '中国近现代史纲要',
    room: '崇D502',
    professor: '苑爽',
    timeslotId: 4
})
data.push({
    groupId: 12,
    groupName: '2020计科56班',
    module: '概率论与数理统计',
    room: '体育305',
    professor: '张伟',
    timeslotId: 7
})
data.push({
    groupId: 12,
    groupName: '2020计科56班',
    module: '体育3',
    room: '',
    professor: '',
    timeslotId: 10
})
data.push({
    groupId: 12,
    groupName: '2020计科56班',
    module: '大学英语3',
    room: '',
    professor: '',
    timeslotId: 12
})
data.push({
    groupId: 12,
    groupName: '2020计科56班',
    module: '概率论与数理统计',
    room: '崇C101',
    professor: '张伟',
    timeslotId: 13
})
data.push({
    groupId: 12,
    groupName: '2020计科56班',
    module: '中国近现代史纲要',
    room: '崇D502',
    professor: '苑爽',
    timeslotId: 14
})
data.push({
    groupId: 13,
    groupName: '2020软件工程12班',
    module: '大学英语3',
    room: '',
    professor: '',
    timeslotId: 1
})
data.push({
    groupId: 13,
    groupName: '2020软件工程12班',
    module: '概率论与数理统计',
    room: '体育307',
    professor: '刘靖宇',
    timeslotId: 6
})
data.push({
    groupId: 13,
    groupName: '2020软件工程12班',
    module: '中国近现代史纲要',
    room: '崇C306',
    professor: '苑爽',
    timeslotId: 7
})
data.push({
    groupId: 13,
    groupName: '2020软件工程12班',
    module: '体育3',
    room: '',
    professor: '',
    timeslotId: 10
})
data.push({
    groupId: 13,
    groupName: '2020软件工程12班',
    module: '大学英语3(双)',
    room: '',
    professor: '',
    timeslotId: 12
})
data.push({
    groupId: 13,
    groupName: '2020软件工程12班',
    module: '中国近现代史纲要',
    room: '崇C306',
    professor: '苑爽',
    timeslotId: 15
})
data.push({
    groupId: 14,
    groupName: '2020软件工程34班',
    module: '大学英语3',
    room: '',
    professor: '',
    timeslotId: 1
})
data.push({
    groupId: 14,
    groupName: '2020软件工程34班',
    module: '中国近现代史纲要',
    room: '崇C306',
    professor: '苑爽',
    timeslotId: 7
})
data.push({
    groupId: 14,
    groupName: '2020软件工程34班',
    module: '体育3',
    room: '',
    professor: '',
    timeslotId: 10
})
data.push({
    groupId: 14,
    groupName: '2020软件工程34班',
    module: '中国近现代史纲要',
    room: '崇C306',
    professor: '苑爽',
    timeslotId: 15
})
data.push({
    groupId: 14,
    groupName: '2020软件工程34班',
    module: '概率论与数理统计',
    room: '体育307',
    professor: '刘靖宇',
    timeslotId: 5
})
data.push({
    groupId: 14,
    groupName: '2020软件工程34班',
    module: '大学英语3（双）',
    room: '',
    professor: '',
    timeslotId: 12
})
data.push({
    groupId: 15,
    groupName: '2020数媒',
    module: '大学英语3',
    room: '',
    professor: '',
    timeslotId: 1
})
data.push({
    groupId: 15,
    groupName: '2020数媒',
    module: '中国近现代史纲要',
    room: '崇C306',
    professor: '苑爽',
    timeslotId: 5
})
data.push({
    groupId: 15,
    groupName: '2020数媒',
    module: '概率论与数理统计',
    room: '崇C306',
    professor: '王禹贺',
    timeslotId: 6
})
data.push({
    groupId: 15,
    groupName: '2020数媒',
    module: '体育3',
    room: '',
    professor: '',
    timeslotId: 10
})
data.push({
    groupId: 15,
    groupName: '2020数媒',
    module: '概率论与数理统计',
    room: '理工一519',
    professor: '王禹贺',
    timeslotId: 11
})
data.push({
    groupId: 15,
    groupName: '2020数媒',
    module: '大学英语3（双）计算机图形学（单）',
    room: '理工一435',
    professor: '崔艳玲',
    timeslotId: 12
})
data.push({
    groupId: 15,
    groupName: '2020数媒',
    module: '中国近现代史纲要',
    room: '崇C306',
    professor: '苑爽',
    timeslotId: 13
})
data.push({
    groupId: 16,
    groupName: '2020物联网工程',
    module: '大学英语3',
    room: '',
    professor: '',
    timeslotId: 1
})
data.push({
    groupId: 16,
    groupName: '2020物联网工程',
    module: '中国近现代史纲要',
    room: '崇C306',
    professor: '苑爽',
    timeslotId: 3
})
data.push({
    groupId: 16,
    groupName: '2020物联网工程',
    module: '概率论与数理统计',
    room: '崇C306',
    professor: '郑岩',
    timeslotId: 4
})
data.push({
    groupId: 16,
    groupName: '2020物联网工程',
    module: '概率论与数理统计1-8&&数字电子技术应用实践9-16',
    room: '体育209&&理工一433',
    professor: '郑岩，倪蕴涛',
    timeslotId: 7
})
data.push({
    groupId: 16,
    groupName: '2020物联网工程',
    module: '体育3',
    room: '',
    professor: '',
    timeslotId: 10
})
data.push({
    groupId: 16,
    groupName: '2020物联网工程',
    module: '大学英语(双)&&数字电子技术(单)',
    room: '体育209',
    professor: '倪蕴涛',
    timeslotId: 12
})
data.push({
    groupId: 16,
    groupName: '2020物联网工程',
    module: '中国近现代史纲要',
    room: '崇C306',
    professor: '苑爽',
    timeslotId: 16
})
data.push({
    groupId: 17,
    groupName: '2020大数据1班',
    module: '大学英语3',
    room: '',
    professor: '',
    timeslotId: 1
})
data.push({
    groupId: 17,
    groupName: '2020大数据1班',
    module: '中国近现代史纲要',
    room: '崇C306',
    professor: '苑爽',
    timeslotId: 3
})
data.push({
    groupId: 17,
    groupName: '2020大数据1班',
    module: '概率论与数理统计',
    room: '理工一523',
    professor: '张馥菊',
    timeslotId: 5
})
data.push({
    groupId: 17,
    groupName: '2020大数据1班',
    module: '体育3',
    room: '',
    professor: '',
    timeslotId: 10
})
data.push({
    groupId: 17,
    groupName: '2020大数据1班',
    module: '概率论与数理统计',
    room: '理工一523',
    professor: '张馥菊',
    timeslotId: 11
})
data.push({
    groupId: 17,
    groupName: '2020大数据1班',
    module: '大学英语3',
    room: '',
    professor: '',
    timeslotId: 12
})
data.push({
    groupId: 17,
    groupName: '2020大数据1班',
    module: '中国近现代史纲要',
    room: '崇C306',
    professor: '苑爽',
    timeslotId: 16
})
data.push({
    groupId: 18,
    groupName: '2019计科1班',
    module: '中学生心理发展与学习',
    room: '崇师楼B318',
    professor: '张洪岩',
    timeslotId: 5
})
data.push({
    groupId: 18,
    groupName: '2019计科1班',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 6
})
data.push({
    groupId: 18,
    groupName: '2019计科1班',
    module: '习近平总书记系列重要讲话精神专题辅导',
    room: '崇D502',
    professor: '邸春玲',
    timeslotId: 11
})
data.push({
    groupId: 18,
    groupName: '2019计科1班',
    module: '中外教育发展简史',
    room: '崇师B318',
    professor: '张超',
    timeslotId: 15
})
data.push({
    groupId: 18,
    groupName: '2019计科1班',
    module: '课程设计与评价',
    room: '社科429',
    professor: '温宏宇',
    timeslotId: 16
})
data.push({
    groupId: 18,
    groupName: '2019计科1班',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 17
})
data.push({
    groupId: 19,
    groupName: '2019计科2班',
    module: '中学生心理发展与学习',
    room: '崇师楼B318',
    professor: '张洪岩',
    timeslotId: 5
})
data.push({
    groupId: 19,
    groupName: '2019计科2班',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 6
})
data.push({
    groupId: 19,
    groupName: '2019计科2班',
    module: '习近平总书记系列重要讲话精神专题辅导',
    room: '崇D502',
    professor: '邸春玲',
    timeslotId: 11
})
data.push({
    groupId: 19,
    groupName: '2019计科2班',
    module: '中外教育发展简史',
    room: '崇师B318',
    professor: '张超',
    timeslotId: 15
})
data.push({
    groupId: 19,
    groupName: '2019计科2班',
    module: '课程设计与评价',
    room: '社科429',
    professor: '温宏宇',
    timeslotId: 16
})
data.push({
    groupId: 19,
    groupName: '2019计科2班',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 17
})
data.push({
    groupId: 20,
    groupName: '2019计科嵌入式',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 6
})
data.push({
    groupId: 20,
    groupName: '2019计科嵌入式',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 7
})
data.push({
    groupId: 20,
    groupName: '2019计科嵌入式',
    module: '习近平总书记系列重要讲话精神专题辅导1-8&&数据库设计与应用9-16',
    room: '崇D502,理工一511',
    professor: '邸春玲,林琳',
    timeslotId: 11
})
data.push({
    groupId: 20,
    groupName: '2019计科嵌入式',
    module: '习近平总书记系列重要讲话精神专题辅导1-8&&ARM体系结构|9-16',
    room: '崇D502，崇C101',
    professor: '邸春玲，张广玲',
    timeslotId: 12
})
data.push({
    groupId: 20,
    groupName: '2019计科嵌入式',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 16
})
data.push({
    groupId: 20,
    groupName: '2019计科嵌入式',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 17
})
data.push({
    groupId: 21,
    groupName: '2019计科软件方向',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 6
})
data.push({
    groupId: 21,
    groupName: '2019计科软件方向',
    module: '习近平总书记系列重要讲话精神专题辅导',
    room: '崇D502',
    professor: '邸春玲',
    timeslotId: 11
})
data.push({
    groupId: 21,
    groupName: '2019计科软件方向',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 17
})
data.push({
    groupId: 22,
    groupName: '2019软件工程架构方向',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 7
})
data.push({
    groupId: 22,
    groupName: '2019软件工程架构方向',
    module: '习近平总书记系列重要讲话精神专题辅导',
    room: '崇D502',
    professor: '邸春玲',
    timeslotId: 12
})
data.push({
    groupId: 22,
    groupName: '2019软件工程架构方向',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 16
})
data.push({
    groupId: 23,
    groupName: '2019软件工程互联方向',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 7
})
data.push({
    groupId: 23,
    groupName: '2019软件工程互联方向',
    module: '习近平总书记系列重要讲话精神专题辅导1-8&&操作系统9-16',
    room: '崇D502，体育308',
    professor: '邸春玲,伦立军',
    timeslotId: 12
})
data.push({
    groupId: 23,
    groupName: '2019软件工程互联方向',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 16
})
data.push({
    groupId: 24,
    groupName: '2019数媒',
    module: '马克思主义基本原理概论1-12&&游戏场景设计|B方向13-16',
    room: '崇D502&&理工一437',
    professor: '胡莹,邸佳奇',
    timeslotId: 13
})
data.push({
    groupId: 24,
    groupName: '2019数媒',
    module: '习近平总书记系列重要讲话精神专题辅导|1-8',
    room: '崇D502',
    professor: '翟屿潼',
    timeslotId: 15
})
data.push({
    groupId: 24,
    groupName: '2019数媒',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 18
})
data.push({
    groupId: 25,
    groupName: '2019物联网工程',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 13
})
data.push({
    groupId: 25,
    groupName: '2019物联网工程',
    module: '习近平总书记系列重要讲话精神专题辅导|1-8',
    room: '崇D502',
    professor: '翟屿潼',
    timeslotId: 15
})
data.push({
    groupId: 25,
    groupName: '2019物联网工程',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 18
})
data.push({
    groupId: 26,
    groupName: '2019大数据1班',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 7
})
data.push({
    groupId: 26,
    groupName: '2019大数据1班',
    module: '习近平总书记系列重要讲话精神专题辅导|1-8',
    room: '崇D502',
    professor: '邸春玲',
    timeslotId: 12
})
data.push({
    groupId: 26,
    groupName: '2019大数据1班',
    module: '马克思主义基本原理概论',
    room: '崇D502',
    professor: '胡莹',
    timeslotId: 16
})