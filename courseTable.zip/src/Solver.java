public class Solver {
}
